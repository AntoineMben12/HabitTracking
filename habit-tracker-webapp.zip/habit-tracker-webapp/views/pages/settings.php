<?php $user = find_user_by_id(current_user_id()); ?>
<div class="card settings-card">
    <div class="section-head">
        <h3>Profile settings</h3>
        <span class="mini-tag">Clean profile control</span>
    </div>
    <form method="post" class="form-grid">
        <input type="hidden" name="action" value="update_settings">
        <label>Full name
            <input type="text" name="full_name" value="<?= e($user['full_name'] ?? '') ?>" required>
        </label>
        <label>Email
            <input type="email" value="<?= e($user['email'] ?? '') ?>" disabled>
        </label>
        <label>Weekly goal
            <input type="number" name="weekly_goal" min="1" max="50" value="<?= (int)($user['weekly_goal'] ?? 5) ?>">
        </label>
        <div class="settings-box">
            <h4>UI style</h4>
            <p class="muted">This project uses a calm three-color palette for a professional look.</p>
        </div>
        <button class="btn btn-primary" type="submit">Save settings</button>
    </form>
</div>
