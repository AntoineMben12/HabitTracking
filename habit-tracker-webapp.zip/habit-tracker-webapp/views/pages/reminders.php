<?php $reminders = get_reminders(current_user_id()); $habits = get_habits(current_user_id()); ?>
<section class="grid-two">
    <div class="card">
        <div class="section-head">
            <h3>Add reminder</h3>
            <span class="mini-tag">Stay on track</span>
        </div>
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="create_reminder">
            <label>Habit
                <select name="habit_id">
                    <option value="0">General reminder</option>
                    <?php foreach ($habits as $habit): ?>
                        <option value="<?= (int)$habit['id'] ?>"><?= e($habit['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Title
                <input type="text" name="title" placeholder="Morning water reminder" required>
            </label>
            <label>Time
                <input type="time" name="reminder_time" required>
            </label>
            <label>Repeat
                <select name="repeat_type">
                    <option value="once">Once</option>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                </select>
            </label>
            <button class="btn btn-primary" type="submit">Add reminder</button>
        </form>
    </div>

    <div class="card">
        <div class="section-head">
            <h3>Active reminders</h3>
            <span class="mini-tag"><?= count($reminders) ?> total</span>
        </div>
        <?php if (empty($reminders)): ?>
            <p class="empty-state">No reminders yet. Create one to support your habit routine.</p>
        <?php else: ?>
            <div class="reminder-list">
                <?php foreach ($reminders as $reminder): ?>
                    <article class="reminder-item">
                        <div>
                            <h4><?= e($reminder['title']) ?></h4>
                            <p>
                                <?= e($reminder['habit_title'] ?? 'General') ?> ·
                                <?= e(substr($reminder['reminder_time'], 0, 5)) ?> ·
                                <?= e($reminder['repeat_type']) ?>
                            </p>
                        </div>
                        <span class="badge <?= (int)$reminder['is_active'] === 1 ? 'badge-success' : 'badge-muted' ?>">
                            <?= (int)$reminder['is_active'] === 1 ? 'Active' : 'Paused' ?>
                        </span>
                        <div class="habit-actions">
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="delete_reminder">
                                <input type="hidden" name="reminder_id" value="<?= (int)$reminder['id'] ?>">
                                <button class="btn btn-danger" type="submit" data-confirm="Delete this reminder?">Delete</button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
