<?php
function find_user_by_email(string $email): ?array {
    return db_select_one('SELECT * FROM users WHERE email = ?', 's', [$email]);
}

function find_user_by_id(int $id): ?array {
    return db_select_one('SELECT * FROM users WHERE id = ?', 'i', [$id]);
}

function create_user(string $fullName, string $email, string $password, int $weeklyGoal = 5): bool {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    return db_execute(
        'INSERT INTO users (full_name, email, password, weekly_goal) VALUES (?, ?, ?, ?)',
        'sssi',
        [$fullName, $email, $hash, $weeklyGoal]
    );
}

function update_user_profile(int $userId, string $fullName, int $weeklyGoal): bool {
    return db_execute(
        'UPDATE users SET full_name = ?, weekly_goal = ? WHERE id = ?',
        'sii',
        [$fullName, $weeklyGoal, $userId]
    );
}
