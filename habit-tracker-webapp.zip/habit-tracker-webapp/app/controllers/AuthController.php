<?php
function handle_register(): void {
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
        flash_set('danger', 'Please fill all registration fields.');
        redirect_to('login');
    }

    if ($password !== $confirm) {
        flash_set('danger', 'Password confirmation does not match.');
        redirect_to('login');
    }

    if (find_user_by_email($email)) {
        flash_set('danger', 'This email is already registered.');
        redirect_to('login');
    }

    if (create_user($name, $email, $password, 5)) {
        flash_set('success', 'Account created successfully. You can now log in.');
    } else {
        flash_set('danger', 'Registration failed. Please try again.');
    }
    redirect_to('login');
}

function handle_login(): void {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $user = find_user_by_email($email);
    if (!$user || !password_verify($password, $user['password'])) {
        flash_set('danger', 'Invalid email or password.');
        redirect_to('login');
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_email'] = $user['email'];

    flash_set('success', 'Welcome back, ' . $user['full_name'] . '.');
    redirect_to('dashboard');
}

function handle_logout(): void {
    session_unset();
    session_destroy();
    session_start();
    flash_set('success', 'You have been logged out.');
    redirect_to('login');
}
