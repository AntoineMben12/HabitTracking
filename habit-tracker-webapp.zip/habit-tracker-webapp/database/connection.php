<?php
$config = require __DIR__ . '/config.php';

$db = mysqli_connect($config['host'], $config['user'], $config['pass'], $config['name']);

if (!$db) {
    die('Database connection failed: ' . mysqli_connect_error());
}

mysqli_set_charset($db, 'utf8mb4');
