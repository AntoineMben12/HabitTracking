# Habit Tracker Web App

A clean PHP/MySQL habit tracker with these screens:
Login, Habits, Progress, Charts, Reminders, and Settings.

## Tech stack
- HTML
- CSS
- JavaScript
- PHP
- MySQL

## Folder structure
- `database/` for connection and schema
- `app/` for shared helpers, controllers, and models
- `views/` for pages, includes, and assets
- `views/assets/style/` for CSS
- `views/assets/js/` for JavaScript

## Setup
1. Import `database/schema.sql` into MySQL.
2. Edit `database/config.php` with your database credentials.
3. Put the project in your PHP server folder.
4. Open `index.php` in the browser.

## Features
- Register and login
- Create, edit, delete, and complete habits
- Weekly progress overview
- Simple charts
- Reminders manager
- Profile and goal settings

## Notes
- The project uses `mysqli` and does not use PDO.
- The UI uses one professional palette with three main colors plus neutrals.
