document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-confirm]').forEach((button) => {
        button.addEventListener('click', (event) => {
            const message = button.getAttribute('data-confirm') || 'Are you sure?';
            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    const sidebar = document.querySelector('.sidebar');
    const toggle = document.querySelector('[data-toggle-sidebar]');
    if (toggle && sidebar) {
        toggle.addEventListener('click', () => sidebar.classList.toggle('open'));
        document.addEventListener('click', (event) => {
            if (window.innerWidth <= 800 && sidebar.classList.contains('open')) {
                const clickedInside = sidebar.contains(event.target) || toggle.contains(event.target);
                if (!clickedInside) sidebar.classList.remove('open');
            }
        });
    }

    const chart = document.getElementById('weekChart');
    if (chart) {
        const labels = JSON.parse(chart.dataset.labels || '[]');
        const values = JSON.parse(chart.dataset.values || '[]');
        const ctx = chart.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        const rect = chart.getBoundingClientRect();
        chart.width = rect.width * dpr;
        chart.height = 260 * dpr;
        ctx.scale(dpr, dpr);
        const width = rect.width;
        const height = 260;
        const pad = 30;
        const chartHeight = height - pad * 2;
        const max = Math.max(1, ...values);
        const barGap = 12;
        const barWidth = (width - pad * 2 - (labels.length - 1) * barGap) / labels.length;

        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.strokeStyle = '#d9e1ee';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(pad, height - pad);
        ctx.lineTo(width - pad, height - pad);
        ctx.stroke();

        values.forEach((value, index) => {
            const barHeight = (value / max) * chartHeight;
            const x = pad + index * (barWidth + barGap);
            const y = height - pad - barHeight;
            const gradient = ctx.createLinearGradient(x, y, x, height - pad);
            gradient.addColorStop(0, '#1e3a8a');
            gradient.addColorStop(1, '#14b8a6');
            ctx.fillStyle = gradient;
            roundRect(ctx, x, y, barWidth, barHeight, 10);
            ctx.fill();

            ctx.fillStyle = '#64748b';
            ctx.font = '12px system-ui';
            ctx.textAlign = 'center';
            ctx.fillText(labels[index], x + barWidth / 2, height - 10);
            ctx.fillText(String(value), x + barWidth / 2, y - 8);
        });
    }

    const editPanel = document.getElementById('habit-edit-panel');
    const closeEdit = document.querySelector('[data-close-edit]');
    document.querySelectorAll('[data-edit-habit]').forEach((button) => {
        button.addEventListener('click', () => {
            const habit = JSON.parse(button.getAttribute('data-edit-habit') || '{}');
            const fields = {
                id: document.getElementById('edit-habit-id'),
                title: document.getElementById('edit-title'),
                category: document.getElementById('edit-category'),
                target: document.getElementById('edit-target'),
                icon: document.getElementById('edit-icon'),
                description: document.getElementById('edit-description'),
            };
            if (fields.id) fields.id.value = habit.id || '';
            if (fields.title) fields.title.value = habit.title || '';
            if (fields.category) fields.category.value = habit.category || '';
            if (fields.target) fields.target.value = habit.target_per_week || 5;
            if (fields.icon) fields.icon.value = habit.icon || '★';
            if (fields.description) fields.description.value = habit.description || '';
            if (editPanel) editPanel.hidden = false;
            editPanel?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });
    closeEdit?.addEventListener('click', () => {
        if (editPanel) editPanel.hidden = true;
    });
});

function roundRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + width - r, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + r);
    ctx.lineTo(x + width, y + height - r);
    ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    ctx.lineTo(x + r, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}
