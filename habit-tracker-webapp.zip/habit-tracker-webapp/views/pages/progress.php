<?php $summary = get_progress_summary(current_user_id()); ?>
<section class="cards-grid">
    <article class="card stat-card">
        <span>This week</span>
        <strong><?= (int)$summary['week_done'] ?></strong>
    </article>
    <article class="card stat-card">
        <span>Goal volume</span>
        <strong><?= (int)$summary['goal_week'] ?></strong>
    </article>
    <article class="card stat-card">
        <span>Rate</span>
        <strong><?= (int)$summary['completion_rate'] ?>%</strong>
    </article>
    <article class="card stat-card">
        <span>Daily done</span>
        <strong><?= (int)$summary['done_today'] ?></strong>
    </article>
</section>

<div class="card">
    <div class="section-head">
        <h3>Habit progress breakdown</h3>
        <span class="mini-tag">Last 7 days</span>
    </div>
    <div class="progress-list">
        <?php foreach ($summary['habits'] as $habit): ?>
            <div class="progress-row">
                <div class="progress-row-top">
                    <div>
                        <h4><?= e($habit['icon']) ?> <?= e($habit['title']) ?></h4>
                        <p><?= e($habit['category']) ?></p>
                    </div>
                    <strong><?= (int)$habit['week_done'] ?>/<?= (int)$habit['target_per_week'] ?></strong>
                </div>
                <div class="progress-bar">
                    <span style="width: <?= (int)$habit['week_progress'] ?>%"></span>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (empty($summary['habits'])): ?>
            <p class="empty-state">Add habits to see detailed progress here.</p>
        <?php endif; ?>
    </div>
</div>
