<?php
function handle_create_habit(): void {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? 'Personal');
    $target = max(1, (int)($_POST['target_per_week'] ?? 5));
    $icon = trim($_POST['icon'] ?? '★');

    if ($title === '') {
        flash_set('danger', 'Habit title is required.');
        redirect_to('habits');
    }

    if (create_habit(current_user_id(), $title, $description, $category, $target, $icon)) {
        flash_set('success', 'Habit created successfully.');
    } else {
        flash_set('danger', 'Could not create habit.');
    }
    redirect_to('habits');
}

function handle_update_habit(): void {
    $habitId = (int)($_POST['habit_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? 'Personal');
    $target = max(1, (int)($_POST['target_per_week'] ?? 5));
    $icon = trim($_POST['icon'] ?? '★');

    if ($habitId <= 0 || $title === '') {
        flash_set('danger', 'Invalid habit data.');
        redirect_to('habits');
    }

    if (update_habit($habitId, current_user_id(), $title, $description, $category, $target, $icon)) {
        flash_set('success', 'Habit updated successfully.');
    } else {
        flash_set('danger', 'Could not update habit.');
    }
    redirect_to('habits');
}

function handle_delete_habit(): void {
    $habitId = (int)($_POST['habit_id'] ?? 0);
    if ($habitId > 0 && delete_habit($habitId, current_user_id())) {
        flash_set('success', 'Habit deleted.');
    } else {
        flash_set('danger', 'Could not delete habit.');
    }
    redirect_to('habits');
}

function handle_toggle_habit(): void {
    $habitId = (int)($_POST['habit_id'] ?? 0);
    if ($habitId > 0 && toggle_habit_today($habitId, current_user_id())) {
        flash_set('success', 'Habit status updated for today.');
    } else {
        flash_set('danger', 'Could not update habit status.');
    }
    redirect_to('habits');
}
