<?php $habits = get_habits(current_user_id()); ?>
<section class="grid-two">
    <div class="card">
        <div class="section-head">
            <h3>Add new habit</h3>
            <span class="mini-tag">Plan your routine</span>
        </div>
        <form method="post" class="form-grid">
            <input type="hidden" name="action" value="create_habit">
            <label>Title
                <input type="text" name="title" placeholder="Drink water" required>
            </label>
            <label>Category
                <input type="text" name="category" placeholder="Health" value="Health">
            </label>
            <label>Target / week
                <input type="number" name="target_per_week" min="1" max="21" value="5">
            </label>
            <label>Icon
                <input type="text" name="icon" maxlength="4" value="★">
            </label>
            <label class="full-span">Description
                <textarea name="description" rows="4" placeholder="Short habit description"></textarea>
            </label>
            <button class="btn btn-primary" type="submit">Save habit</button>
        </form>
    </div>

    <div class="card">
        <div class="section-head">
            <h3>Your habits</h3>
            <span class="mini-tag"><?= count($habits) ?> items</span>
        </div>
        <?php if (empty($habits)): ?>
            <p class="empty-state">No habits yet. Add one on the left.</p>
        <?php else: ?>
            <div class="habit-list">
                <?php foreach ($habits as $habit): ?>
                    <article class="habit-item">
                        <div class="habit-item-top">
                            <div>
                                <h4><?= e($habit['icon']) ?> <?= e($habit['title']) ?></h4>
                                <p><?= e($habit['category']) ?> · Goal <?= (int)$habit['target_per_week'] ?>/week</p>
                            </div>
                            <span class="badge <?= $habit['is_done_today'] ? 'badge-success' : 'badge-muted' ?>">
                                <?= $habit['is_done_today'] ? 'Today done' : 'Need action' ?>
                            </span>
                        </div>
                        <?php if (!empty($habit['description'])): ?>
                            <p class="habit-desc"><?= e($habit['description']) ?></p>
                        <?php endif; ?>
                        <div class="habit-actions">
                            <form method="post">
                                <input type="hidden" name="action" value="toggle_habit">
                                <input type="hidden" name="habit_id" value="<?= (int)$habit['id'] ?>">
                                <button class="btn btn-secondary" type="submit">
                                    <?= $habit['is_done_today'] ? 'Undo today' : 'Mark done today' ?>
                                </button>
                            </form>
                            <button class="btn btn-ghost" data-edit-habit='<?= e(json_encode($habit, JSON_UNESCAPED_UNICODE)) ?>'>Edit</button>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="action" value="delete_habit">
                                <input type="hidden" name="habit_id" value="<?= (int)$habit['id'] ?>">
                                <button class="btn btn-danger" type="submit" data-confirm="Delete this habit?">Delete</button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<div class="card modal-panel" id="habit-edit-panel" hidden>
    <div class="section-head">
        <h3>Edit habit</h3>
        <button class="btn btn-ghost" data-close-edit>Edit</button>
    </div>
    <form method="post" class="form-grid">
        <input type="hidden" name="action" value="update_habit">
        <input type="hidden" name="habit_id" id="edit-habit-id">
        <label>Title
            <input type="text" name="title" id="edit-title" required>
        </label>
        <label>Category
            <input type="text" name="category" id="edit-category">
        </label>
        <label>Target / week
            <input type="number" name="target_per_week" id="edit-target" min="1" max="21">
        </label>
        <label>Icon
            <input type="text" name="icon" id="edit-icon" maxlength="4">
        </label>
        <label class="full-span">Description
            <textarea name="description" id="edit-description" rows="4"></textarea>
        </label>
        <button class="btn btn-primary" type="submit">Update habit</button>
    </form>
</div>
