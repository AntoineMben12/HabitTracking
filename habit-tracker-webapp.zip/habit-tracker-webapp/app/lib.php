<?php
function db_conn() {
    global $db;
    return $db;
}

function bind_stmt_params(mysqli_stmt $stmt, string $types, array &$params): void {
    $bind_names = [$stmt, $types];
    foreach ($params as $key => $value) {
        $bind_names[] = &$params[$key];
    }
    call_user_func_array('mysqli_stmt_bind_param', $bind_names);
}

function db_execute(string $sql, string $types = '', array $params = []): bool {
    $stmt = mysqli_prepare(db_conn(), $sql);
    if (!$stmt) {
        return false;
    }
    if ($types !== '') {
        bind_stmt_params($stmt, $types, $params);
    }
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

function db_insert_id(): int {
    return mysqli_insert_id(db_conn());
}

function db_select_all(string $sql, string $types = '', array $params = []): array {
    $stmt = mysqli_prepare(db_conn(), $sql);
    if (!$stmt) {
        return [];
    }
    if ($types !== '') {
        bind_stmt_params($stmt, $types, $params);
    }
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $rows = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
    }
    mysqli_stmt_close($stmt);
    return $rows;
}

function db_select_one(string $sql, string $types = '', array $params = []): ?array {
    $rows = db_select_all($sql, $types, $params);
    return $rows[0] ?? null;
}

function e($value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect_to(string $page): void {
    header('Location: index.php?page=' . urlencode($page));
    exit;
}

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function current_user_id(): int {
    return (int)($_SESSION['user_id'] ?? 0);
}

function current_user_name(): string {
    return $_SESSION['user_name'] ?? 'Guest';
}

function flash_set(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function flash_get(): ?array {
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function require_login(): void {
    if (!is_logged_in()) {
        redirect_to('login');
    }
}

function today_date(): string {
    return date('Y-m-d');
}

function week_dates(): array {
    $dates = [];
    for ($i = 6; $i >= 0; $i--) {
        $dates[] = date('Y-m-d', strtotime('-' . $i . ' days'));
    }
    return $dates;
}

function percent($part, $whole): int {
    $whole = max((int)$whole, 1);
    return (int) round(((int)$part / $whole) * 100);
}
