<?php
function get_reminders(int $userId): array {
    return db_select_all(
        'SELECT r.*, h.title AS habit_title
         FROM reminders r
         LEFT JOIN habits h ON h.id = r.habit_id
         WHERE r.user_id = ?
         ORDER BY r.is_active DESC, r.reminder_time ASC, r.created_at DESC',
        'i',
        [$userId]
    );
}

function create_reminder(int $userId, ?int $habitId, string $title, string $time, string $repeatType): bool {
    if ($habitId === null) {
        return db_execute(
            'INSERT INTO reminders (user_id, habit_id, title, reminder_time, repeat_type) VALUES (?, NULL, ?, ?, ?)',
            'isss',
            [$userId, $title, $time, $repeatType]
        );
    }
    return db_execute(
        'INSERT INTO reminders (user_id, habit_id, title, reminder_time, repeat_type) VALUES (?, ?, ?, ?, ?)',
        'iisss',
        [$userId, $habitId, $title, $time, $repeatType]
    );
}

function update_reminder(int $reminderId, int $userId, ?int $habitId, string $title, string $time, string $repeatType, int $isActive): bool {
    if ($habitId === null) {
        return db_execute(
            'UPDATE reminders SET habit_id = NULL, title = ?, reminder_time = ?, repeat_type = ?, is_active = ? WHERE id = ? AND user_id = ?',
            'sssiii',
            [$title, $time, $repeatType, $isActive, $reminderId, $userId]
        );
    }

    return db_execute(
        'UPDATE reminders SET habit_id = ?, title = ?, reminder_time = ?, repeat_type = ?, is_active = ? WHERE id = ? AND user_id = ?',
        'isssiii',
        [$habitId, $title, $time, $repeatType, $isActive, $reminderId, $userId]
    );
}

function delete_reminder(int $reminderId, int $userId): bool {
    return db_execute('DELETE FROM reminders WHERE id = ? AND user_id = ?', 'ii', [$reminderId, $userId]);
}
