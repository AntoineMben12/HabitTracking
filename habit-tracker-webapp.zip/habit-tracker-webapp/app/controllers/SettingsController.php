<?php
function handle_update_settings(): void {
    $fullName = trim($_POST['full_name'] ?? '');
    $weeklyGoal = max(1, (int)($_POST['weekly_goal'] ?? 5));

    if ($fullName === '') {
        flash_set('danger', 'Full name is required.');
        redirect_to('settings');
    }

    if (update_user_profile(current_user_id(), $fullName, $weeklyGoal)) {
        $_SESSION['user_name'] = $fullName;
        flash_set('success', 'Settings saved successfully.');
    } else {
        flash_set('danger', 'Could not save settings.');
    }
    redirect_to('settings');
}
