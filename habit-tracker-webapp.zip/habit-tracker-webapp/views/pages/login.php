<div class="auth-grid">
    <section class="hero-card">
        <p class="eyebrow">Habit Tracker</p>
        <h1>Track your daily habits with clarity and consistency.</h1>
        <p class="hero-text">Manage routines, measure progress, and keep reminders in one clean dashboard.</p>
        <div class="hero-stats">
            <div><strong>6</strong><span>screens</span></div>
            <div><strong>1</strong><span>workflow</span></div>
            <div><strong>100%</strong><span>focus</span></div>
        </div>
    </section>

    <section class="auth-card">
        <h2>Login</h2>
        <form method="post" class="form-stack">
            <input type="hidden" name="action" value="login">
            <label>Email
                <input type="email" name="email" placeholder="you@example.com" required>
            </label>
            <label>Password
                <input type="password" name="password" placeholder="Your password" required>
            </label>
            <button class="btn btn-primary" type="submit">Sign in</button>
        </form>

        <hr>

        <h2>Create account</h2>
        <form method="post" class="form-stack">
            <input type="hidden" name="action" value="register">
            <label>Full name
                <input type="text" name="full_name" placeholder="Your name" required>
            </label>
            <label>Email
                <input type="email" name="email" placeholder="you@example.com" required>
            </label>
            <label>Password
                <input type="password" name="password" required>
            </label>
            <label>Confirm password
                <input type="password" name="confirm_password" required>
            </label>
            <button class="btn btn-secondary" type="submit">Create account</button>
        </form>
    </section>
</div>
