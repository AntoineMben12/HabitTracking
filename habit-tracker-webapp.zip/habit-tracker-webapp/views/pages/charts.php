<?php $chart = get_week_chart_data(current_user_id()); ?>
<div class="card">
    <div class="section-head">
        <h3>Weekly activity chart</h3>
        <span class="mini-tag">Automatic chart</span>
    </div>
    <canvas id="weekChart" height="260" data-labels='<?= e(json_encode($chart['labels'])) ?>' data-values='<?= e(json_encode($chart['values'])) ?>'></canvas>
</div>

<section class="grid-two mt-20">
    <div class="card">
        <div class="section-head">
            <h3>Chart insight</h3>
        </div>
        <p class="muted">The chart shows completed habit actions for the last 7 days. Increase consistency by keeping the bars steady and balanced.</p>
    </div>
    <div class="card">
        <div class="section-head">
            <h3>What to watch</h3>
        </div>
        <p class="muted">A rising curve means your routine is becoming stable. Use reminders and daily completion to keep the trend moving up.</p>
    </div>
</section>
