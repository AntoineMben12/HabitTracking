<?php $flash = flash_get(); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'Habit Tracker') ?></title>
    <link rel="stylesheet" href="views/assets/style/style.css">
</head>
<body>
<div class="app-shell">
    <?php if (is_logged_in()): ?>
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-mark">HT</div>
            <div>
                <h1>Habit Tracker</h1>
                <p>Build strong routines</p>
            </div>
        </div>
        <nav class="nav">
            <a href="index.php?page=dashboard" class="nav-link <?= $page === 'dashboard' ? 'active' : '' ?>">Dashboard</a>
            <a href="index.php?page=habits" class="nav-link <?= $page === 'habits' ? 'active' : '' ?>">Habits</a>
            <a href="index.php?page=progress" class="nav-link <?= $page === 'progress' ? 'active' : '' ?>">Progress</a>
            <a href="index.php?page=charts" class="nav-link <?= $page === 'charts' ? 'active' : '' ?>">Charts</a>
            <a href="index.php?page=reminders" class="nav-link <?= $page === 'reminders' ? 'active' : '' ?>">Reminders</a>
            <a href="index.php?page=settings" class="nav-link <?= $page === 'settings' ? 'active' : '' ?>">Settings</a>
        </nav>
        <form method="post" class="sidebar-logout">
            <input type="hidden" name="action" value="logout">
            <button type="submit" class="btn btn-ghost">Logout</button>
        </form>
    </aside>
    <?php endif; ?>

    <main class="main-area">
        <?php if (is_logged_in()): ?>
        <header class="topbar">
            <button class="mobile-toggle" data-toggle-sidebar>Menu</button>
            <div>
                <p class="eyebrow">Welcome back</p>
                <h2><?= e(current_user_name()) ?></h2>
            </div>
            <div class="topbar-pill">Focus weekly. Win daily.</div>
        </header>
        <?php endif; ?>

        <?php if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
        <?php endif; ?>
