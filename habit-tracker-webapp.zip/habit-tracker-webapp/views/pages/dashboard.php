<?php $summary = get_progress_summary(current_user_id()); ?>
<section class="cards-grid">
    <article class="card stat-card">
        <span>Total habits</span>
        <strong><?= (int)$summary['total_habits'] ?></strong>
    </article>
    <article class="card stat-card">
        <span>Done today</span>
        <strong><?= (int)$summary['done_today'] ?></strong>
    </article>
    <article class="card stat-card">
        <span>Weekly target</span>
        <strong><?= (int)$summary['goal_week'] ?></strong>
    </article>
    <article class="card stat-card">
        <span>Completion</span>
        <strong><?= (int)$summary['completion_rate'] ?>%</strong>
    </article>
</section>

<section class="grid-two">
    <div class="card">
        <div class="section-head">
            <h3>Today’s focus</h3>
            <a href="index.php?page=habits">Open habits</a>
        </div>
        <?php if (empty($summary['habits'])): ?>
            <p class="empty-state">No habits yet. Create your first habit to start tracking progress.</p>
        <?php else: ?>
            <div class="habit-preview-list">
                <?php foreach (array_slice($summary['habits'], 0, 4) as $habit): ?>
                    <div class="habit-preview">
                        <div>
                            <div class="habit-title"><?= e($habit['icon']) ?> <?= e($habit['title']) ?></div>
                            <p><?= e($habit['category']) ?></p>
                        </div>
                        <span class="badge <?= $habit['is_done_today'] ? 'badge-success' : 'badge-muted' ?>">
                            <?= $habit['is_done_today'] ? 'Done' : 'Pending' ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="section-head">
            <h3>Weekly momentum</h3>
            <a href="index.php?page=charts">View charts</a>
        </div>
        <div class="progress-hero">
            <div class="progress-ring" style="--value: <?= (int)$summary['completion_rate'] ?>">
                <span><?= (int)$summary['completion_rate'] ?>%</span>
            </div>
            <div>
                <p class="muted">You have completed <?= (int)$summary['week_done'] ?> actions this week.</p>
                <p class="muted">Keep the rhythm and stay consistent.</p>
            </div>
        </div>
    </div>
</section>
