<?php
function handle_create_reminder(): void {
    $habitId = (int)($_POST['habit_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $time = $_POST['reminder_time'] ?? '';
    $repeat = $_POST['repeat_type'] ?? 'daily';

    if ($title === '' || $time === '') {
        flash_set('danger', 'Reminder title and time are required.');
        redirect_to('reminders');
    }

    $selectedHabit = $habitId > 0 ? $habitId : null;
    if (create_reminder(current_user_id(), $selectedHabit, $title, $time, $repeat)) {
        flash_set('success', 'Reminder added successfully.');
    } else {
        flash_set('danger', 'Could not add reminder.');
    }
    redirect_to('reminders');
}

function handle_update_reminder(): void {
    $reminderId = (int)($_POST['reminder_id'] ?? 0);
    $habitId = (int)($_POST['habit_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $time = $_POST['reminder_time'] ?? '';
    $repeat = $_POST['repeat_type'] ?? 'daily';
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    $selectedHabit = $habitId > 0 ? $habitId : null;
    if ($reminderId <= 0 || $title === '' || $time === '') {
        flash_set('danger', 'Invalid reminder data.');
        redirect_to('reminders');
    }

    if (update_reminder($reminderId, current_user_id(), $selectedHabit, $title, $time, $repeat, $isActive)) {
        flash_set('success', 'Reminder updated.');
    } else {
        flash_set('danger', 'Could not update reminder.');
    }
    redirect_to('reminders');
}

function handle_delete_reminder(): void {
    $reminderId = (int)($_POST['reminder_id'] ?? 0);
    if ($reminderId > 0 && delete_reminder($reminderId, current_user_id())) {
        flash_set('success', 'Reminder removed.');
    } else {
        flash_set('danger', 'Could not remove reminder.');
    }
    redirect_to('reminders');
}
