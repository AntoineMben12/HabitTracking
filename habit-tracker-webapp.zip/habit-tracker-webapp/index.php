<?php
session_start();
require_once __DIR__ . '/database/connection.php';
require_once __DIR__ . '/app/lib.php';
require_once __DIR__ . '/app/models/UserModel.php';
require_once __DIR__ . '/app/models/HabitModel.php';
require_once __DIR__ . '/app/models/ReminderModel.php';
require_once __DIR__ . '/app/controllers/AuthController.php';
require_once __DIR__ . '/app/controllers/HabitController.php';
require_once __DIR__ . '/app/controllers/ReminderController.php';
require_once __DIR__ . '/app/controllers/SettingsController.php';

$page = $_GET['page'] ?? (is_logged_in() ? 'dashboard' : 'login');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    switch ($action) {
        case 'register':
            handle_register();
            break;
        case 'login':
            handle_login();
            break;
        case 'logout':
            handle_logout();
            break;
        case 'create_habit':
            require_login();
            handle_create_habit();
            break;
        case 'update_habit':
            require_login();
            handle_update_habit();
            break;
        case 'delete_habit':
            require_login();
            handle_delete_habit();
            break;
        case 'toggle_habit':
            require_login();
            handle_toggle_habit();
            break;
        case 'create_reminder':
            require_login();
            handle_create_reminder();
            break;
        case 'update_reminder':
            require_login();
            handle_update_reminder();
            break;
        case 'delete_reminder':
            require_login();
            handle_delete_reminder();
            break;
        case 'update_settings':
            require_login();
            handle_update_settings();
            break;
        default:
            flash_set('danger', 'Unknown action.');
            redirect_to(is_logged_in() ? 'dashboard' : 'login');
    }
}

if (!is_logged_in() && $page !== 'login') {
    redirect_to('login');
}

switch ($page) {
    case 'dashboard':
        $pageTitle = 'Dashboard - Habit Tracker';
        break;
    case 'habits':
        $pageTitle = 'Habits - Habit Tracker';
        break;
    case 'progress':
        $pageTitle = 'Progress - Habit Tracker';
        break;
    case 'charts':
        $pageTitle = 'Charts - Habit Tracker';
        break;
    case 'reminders':
        $pageTitle = 'Reminders - Habit Tracker';
        break;
    case 'settings':
        $pageTitle = 'Settings - Habit Tracker';
        break;
    default:
        $page = 'login';
        $pageTitle = 'Login - Habit Tracker';
}

require_once __DIR__ . '/views/includes/header.php';

if ($page === 'login') {
    require __DIR__ . '/views/pages/login.php';
} elseif ($page === 'dashboard') {
    require __DIR__ . '/views/pages/dashboard.php';
} elseif ($page === 'habits') {
    require __DIR__ . '/views/pages/habits.php';
} elseif ($page === 'progress') {
    require __DIR__ . '/views/pages/progress.php';
} elseif ($page === 'charts') {
    require __DIR__ . '/views/pages/charts.php';
} elseif ($page === 'reminders') {
    require __DIR__ . '/views/pages/reminders.php';
} elseif ($page === 'settings') {
    require __DIR__ . '/views/pages/settings.php';
}

require_once __DIR__ . '/views/includes/footer.php';
