<?php
function get_habits(int $userId): array {
    $habits = db_select_all(
        'SELECT h.*,
            COALESCE(SUM(CASE WHEN hl.completed = 1 AND hl.log_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) THEN 1 ELSE 0 END), 0) AS week_done,
            COALESCE(SUM(CASE WHEN hl.completed = 1 AND hl.log_date = CURDATE() THEN 1 ELSE 0 END), 0) AS today_done
        FROM habits h
        LEFT JOIN habit_logs hl ON hl.habit_id = h.id
        WHERE h.user_id = ?
        GROUP BY h.id
        ORDER BY h.created_at DESC',
        'i',
        [$userId]
    );

    foreach ($habits as &$habit) {
        $habit['week_progress'] = percent($habit['week_done'], $habit['target_per_week']);
        $today = db_select_one('SELECT completed FROM habit_logs WHERE habit_id = ? AND log_date = CURDATE()', 'i', [$habit['id']]);
        $habit['is_done_today'] = !empty($today) && (int)$today['completed'] === 1;
    }
    return $habits;
}

function get_habit(int $habitId, int $userId): ?array {
    return db_select_one('SELECT * FROM habits WHERE id = ? AND user_id = ?', 'ii', [$habitId, $userId]);
}

function create_habit(int $userId, string $title, string $description, string $category, int $targetPerWeek, string $icon): bool {
    return db_execute(
        'INSERT INTO habits (user_id, title, description, category, target_per_week, icon) VALUES (?, ?, ?, ?, ?, ?)',
        'isssis',
        [$userId, $title, $description, $category, $targetPerWeek, $icon]
    );
}

function update_habit(int $habitId, int $userId, string $title, string $description, string $category, int $targetPerWeek, string $icon): bool {
    return db_execute(
        'UPDATE habits SET title = ?, description = ?, category = ?, target_per_week = ?, icon = ? WHERE id = ? AND user_id = ?',
        'sssisii',
        [$title, $description, $category, $targetPerWeek, $icon, $habitId, $userId]
    );
}

function delete_habit(int $habitId, int $userId): bool {
    return db_execute('DELETE FROM habits WHERE id = ? AND user_id = ?', 'ii', [$habitId, $userId]);
}

function toggle_habit_today(int $habitId, int $userId): bool {
    $habit = get_habit($habitId, $userId);
    if (!$habit) {
        return false;
    }
    $existing = db_select_one('SELECT id, completed FROM habit_logs WHERE habit_id = ? AND log_date = CURDATE()', 'i', [$habitId]);
    if ($existing) {
        $next = (int)$existing['completed'] === 1 ? 0 : 1;
        return db_execute('UPDATE habit_logs SET completed = ? WHERE id = ?', 'ii', [$next, (int)$existing['id']]);
    }
    return db_execute('INSERT INTO habit_logs (habit_id, log_date, completed) VALUES (?, CURDATE(), 1)', 'i', [$habitId]);
}

function get_progress_summary(int $userId): array {
    $habits = get_habits($userId);
    $total = count($habits);
    $doneToday = 0;
    $target = 0;
    foreach ($habits as $habit) {
        if (!empty($habit['is_done_today'])) {
            $doneToday++;
        }
        $target += (int)$habit['target_per_week'];
    }
    $weekCompleted = db_select_one(
        'SELECT COUNT(*) AS total_done FROM habit_logs hl INNER JOIN habits h ON h.id = hl.habit_id WHERE h.user_id = ? AND hl.completed = 1 AND hl.log_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)',
        'i',
        [$userId]
    );
    $weekDone = (int)($weekCompleted['total_done'] ?? 0);

    return [
        'total_habits' => $total,
        'done_today' => $doneToday,
        'goal_week' => max($target, 1),
        'week_done' => $weekDone,
        'completion_rate' => percent($weekDone, max($target, 1)),
        'habits' => $habits,
    ];
}

function get_week_chart_data(int $userId): array {
    $rows = db_select_all(
        'SELECT hl.log_date AS day, COUNT(*) AS total
         FROM habit_logs hl
         INNER JOIN habits h ON h.id = hl.habit_id
         WHERE h.user_id = ? AND hl.completed = 1 AND hl.log_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
         GROUP BY hl.log_date
         ORDER BY hl.log_date ASC',
        'i',
        [$userId]
    );

    $map = [];
    foreach ($rows as $row) {
        $map[$row['day']] = (int)$row['total'];
    }

    $labels = [];
    $values = [];
    foreach (week_dates() as $date) {
        $labels[] = date('D', strtotime($date));
        $values[] = $map[$date] ?? 0;
    }

    return ['labels' => $labels, 'values' => $values];
}
